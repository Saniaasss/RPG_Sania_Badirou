package com.school.game_rpg.models;

import com.school.game_rpg.models.Beans.Enemy;
import com.school.game_rpg.models.entities.Figher;
import com.school.game_rpg.models.entities.EnemyGame;
import com.school.game_rpg.models.entities.HeroGame;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class RpgTest {
    @Test
    public void EnemyGame(){

        //Initialisation du test
        Figher figher = new EnemyGame();

        //Réalisation du test
        figher.setVie(2);

        //Validation du test
        assertTrue(((EnemyGame) figher).getVie() > 0);
        //Vrai car 2 > 0
    }

    @Test
    public void EnemyGameFaux(){

        //Initialisation du test
        Figher figher = new EnemyGame();

        //Réalisation du test
        figher.setVie(2);

        //Validation du test
        assertTrue(((EnemyGame) figher).getVie() < 0);
        //Faux car 2 inférieur à 0
    }




    @Test
    public void HeroGame(){

        //Initialisation du test
        Figher figher = new HeroGame();

        //Réalisation du test
        figher.setVie(5);

        //Validation du test
        assertTrue(((HeroGame) figher).getVie() > 0);
        //Vrai car 5 > 0
    }

    @Test
    public void HeroGameFaux(){

        //Initialisation du test
        Figher figher = new HeroGame();

        //Réalisation du test
        figher.setVie(-5);

        //Validation du test
        assertTrue(((HeroGame) figher).getVie() > 0);
        //Faux car -5 inférieur à 0
    }
}
