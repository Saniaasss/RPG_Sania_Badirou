module com.school.game_rpg {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires java.desktop;

    opens com.school.game_rpg to javafx.fxml;
    exports com.school.game_rpg;
    exports com.school.game_rpg.controllers;
    opens com.school.game_rpg.controllers to javafx.fxml;
}