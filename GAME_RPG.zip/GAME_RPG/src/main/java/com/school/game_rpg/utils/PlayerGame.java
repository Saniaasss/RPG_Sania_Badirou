package com.school.game_rpg.utils;

import com.school.game_rpg.models.Beans.*;
import com.school.game_rpg.models.entities.EnemyGame;
import com.school.game_rpg.models.entities.Figher;
import com.school.game_rpg.models.entities.HeroGame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

public class PlayerGame {

    private ArrayList<HeroClass> HereosClass ;

    public static PlayerGame context;

    public static void playGame() {
        if (PlayerGame.context != null) {
            throw new RuntimeException
                    ("Impossible de lancer plusieurs fois la partie...");
        }
        PlayerGame.context = new PlayerGame();
        PlayerGame.context.generateHeroes();
        PlayerGame.context.startCombat();
    }

    public static enum Status {START_COMBAT, HERO_TURN, ENEMY_TURN,DEFENCE,CONSOMMABLE, END_GAME}
    public PlayerGame.Status status;



    private List<HeroGame> heroes;
    public List<String> getHeroesStatus() {
        List<String> heroesStatus = new ArrayList<>();
        List<HeroGame> heroesStatusObj = new ArrayList<>();
        for (HeroGame heroGame: heroesStatusObj){
            heroesStatus.add(heroGame.getName());
        }
        return heroesStatus;
    }
    private List<EnemyGame> enemies;
    public List<String> getEnemiesStatus() {
        List<String> enemyStatus = new ArrayList<>();
        List<EnemyGame> heroesStatusObj = new ArrayList<>();
        for (EnemyGame enemyGame: heroesStatusObj){
            enemyStatus.add(enemyGame.getEnemie());
        }
        return enemyStatus;
    }
    // "fighters" : Les héros et les ennemis mélangés
    private List<Figher> fighters;
    ListIterator<Figher> fightersIterator;

    private Figher currentFighter;

    private int playerTurn;
    private InputParser inputParser;

    // L'instanciation de "Game" ne peut se faire que par "playGame"
    private PlayerGame() {}

    public void startCombat() {
        // Combat avec de nouveaux ennemis tant qu'il y a des héros actifs
        if (this.heroes.size() > 0) {
            this.status = PlayerGame.Status.START_COMBAT;
            generateCombat();
        } else {
            this.status = PlayerGame.Status.END_GAME;
        }
    }

    public void generateCombat() {
        generateEnemies();
        shuffleFighters();
        // Initialise un "curseur" pour parcourir la liste des combattants
         fightersIterator = fighters.listIterator();
    }

    private void generateHeroes() {
        this.heroes = new ArrayList<>();
        this.heroes.add(new HeroGame("Hunter 1"));
        this.heroes.add(new HeroGame("Hunter 2"));
        this.heroes.add(new HeroGame("Warrior"));
        this.heroes.add(new HeroGame("Healer"));

    }

    private void generateEnemies() {
        this.enemies = new ArrayList<>();
        this.enemies.add(new EnemyGame("Boss"));
        this.enemies.add(new EnemyGame("Enemy 1"));
        this.enemies.add(new EnemyGame("Enemy 2"));
        this.enemies.add(new EnemyGame("Enemy 3"));

    }

    // Mélange les héros avec les ennemis dans une liste pour le combat
    private void shuffleFighters() {
        this.fighters = new ArrayList<>();
        this.heroes = new ArrayList<>();
        this.fighters.addAll(this.heroes);
        this.fighters.addAll(this.enemies);
        Collections.shuffle(this.fighters); //--> google "java shuffle list"
    }

    public void startNextFighterTurn() {

        if (this.heroes.size() == 0) {
            this.status = PlayerGame.Status.END_GAME;
        } else if (enemies.size() == 0) {
            this.status = PlayerGame.Status.START_COMBAT;
            generateCombat();
        } else {

            // Récupère le combattant suivant en déplaçant le curseur de liste
            if (!fightersIterator.hasNext()) {
                // Si on est à la fin de la liste, l'itérateur est réinitialisé
                fightersIterator = fighters.listIterator();
            }
            this.currentFighter = fightersIterator.next();



        }


    }
    public void startHeroTurn() {
        // Pour l'instant --> le joueur ne décide pas de l'action du héro
        //                --> le joueur attaque l'ennemi

    }

    public void startEnemyTurn() {
        // L'ennemi attaque au hasard un des héros encore vivant

    }
}
