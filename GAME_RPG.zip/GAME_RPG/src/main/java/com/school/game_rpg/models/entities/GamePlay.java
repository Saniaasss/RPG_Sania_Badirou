package com.school.game_rpg.models.entities;

public class GamePlay {
    private int vie;
    private HeroGame heroGame;
    private EnemyGame enemyGame;

    public GamePlay(HeroGame heroGame, EnemyGame enemyGame) {
        this.heroGame = heroGame;
        this.enemyGame = enemyGame;
    }

    public GamePlay(int vie, HeroGame heroGame, EnemyGame enemyGame) {
        this.vie = vie;
        this.heroGame = heroGame;
        this.enemyGame = enemyGame;
    }

    public int c() {
        return vie;
    }

    public void setVie(int vie) {
        this.vie = vie;
    }

    public HeroGame getHeroGame() {
        return heroGame;
    }

    public void setHeroGame(HeroGame heroGame) {
        this.heroGame = heroGame;
    }

    public EnemyGame getEnemyGame() {
        return enemyGame;
    }

    public void setEnemyGame(EnemyGame enemyGame) {
        this.enemyGame = enemyGame;
    }
}
