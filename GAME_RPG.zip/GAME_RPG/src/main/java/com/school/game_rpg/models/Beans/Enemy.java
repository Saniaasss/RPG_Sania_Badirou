package com.school.game_rpg.models.Beans;

public abstract class Enemy {
    private int lifePoints;
}
