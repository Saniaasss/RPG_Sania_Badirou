package com.school.game_rpg.models.Beans;

public abstract class Fighter {

}
