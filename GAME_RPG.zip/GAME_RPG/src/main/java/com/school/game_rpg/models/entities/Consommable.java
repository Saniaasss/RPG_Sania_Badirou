package com.school.game_rpg.models.entities;

public class Consommable {
    private String food;

    public Consommable() {
    }

    public Consommable(String food) {
        this.food = food;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }
}
