package com.school.game_rpg.controllers;

import com.school.game_rpg.models.entities.EnemyGame;
import com.school.game_rpg.models.entities.HeroGame;
import com.school.game_rpg.utils.PlayerGame;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class PlayController {

    @FXML
    ListView<String> heroList;

    @FXML
    ListView<String> enemyList;

    @FXML
    Button fightButton,consommableButton,defendreButton,validerNombreHeros;

    @FXML
    TextField nombreHeros;

    int nombreHros;

    // "initialize()" est appelé par JavaFX à l'affichage de la fenêtre
    @FXML
    public void initialize() {
        consommableButton.setVisible(false);
        fightButton.setVisible(false);
        defendreButton.setVisible(false);
        heroList.getItems().add("Warrior");
        heroList.getItems().add("Hunter");
        enemyList.getItems().add("Boss");
        enemyList.getItems().add("Enemy");
        PlayerGame.playGame();
    }
    private void updateListViews() {
        validerNombreHeros.setVisible(false);
        nombreHeros.setText(String.valueOf(nombreHros));
        nombreHeros.setDisable(true);
        heroList.getItems().setAll(PlayerGame.context.getHeroesStatus());
        enemyList.getItems().setAll(PlayerGame.context.getEnemiesStatus());
    }
    @FXML
    private void entrerNombreHeros(){
        nombreHros= Integer.parseInt(nombreHeros.getText());
        System.out.println("nombreHros "+nombreHros);
        if (!nombreHeros.getText().isBlank()){
            if (nombreHros<=0 ){
                consommableButton.setVisible(false);
                fightButton.setVisible(false);
                defendreButton.setVisible(false);
            }else if (nombreHros>=5){
                consommableButton.setVisible(false);
                fightButton.setVisible(false);
                defendreButton.setVisible(false);
            }
            else{
                consommableButton.setVisible(true);
                fightButton.setVisible(true);
                defendreButton.setVisible(true);
            }
        }else{
            consommableButton.setVisible(true);
            fightButton.setVisible(true);
            defendreButton.setVisible(true);
        }



    }
    // Action du bouton change en fonction de l'État du jeu
    private void updateFightButton() {
        validerNombreHeros.setVisible(false);
        nombreHeros.setText(String.valueOf(nombreHros));
        nombreHeros.setDisable(true);
        switch (PlayerGame.context.status) {
            case START_COMBAT:
                fightButton.setText("Lancer le combat !");
                fightButton.setOnAction( event -> {
                    updateListViews();
                    PlayerGame.context.startNextFighterTurn();
                    updateFightButton();
                } );
                break;
            case HERO_TURN:
                fightButton.setText("Attaque du héro...");
                fightButton.setOnAction( event -> {
                    PlayerGame.context.startHeroTurn();
                    updateListViews();
                    PlayerGame.context.startNextFighterTurn();
                    updateFightButton();
                } );
                break;
            case ENEMY_TURN:
                fightButton.setText("Attaque de l'ennemi...");
                fightButton.setOnAction( event -> {
                    PlayerGame.context.startEnemyTurn();
                    updateListViews();
                    PlayerGame.context.startNextFighterTurn();
                    updateFightButton();
                } );
                break;
            case DEFENCE:
                defendreButton.setText("Défense...");
                defendreButton.setOnAction( event -> {
                    PlayerGame.context.startHeroTurn();
                    updateListViews();
                    PlayerGame.context.startNextFighterTurn();
                    updateFightButton();
                } );
                break;
            case CONSOMMABLE:
                consommableButton.setText("Consommable...");
                consommableButton.setOnAction( event -> {
                    PlayerGame.context.startHeroTurn();
                    updateListViews();
                    PlayerGame.context.startNextFighterTurn();
                    updateFightButton();
                } );
                break;
            case END_GAME:
                fightButton.setDisable(true);
                //  this.onFinalise();
                ;
                break;
        }
    }

    public int getNombreHros() {
        return nombreHros;
    }

    public void setNombreHros(int nombreHros) {
        this.nombreHros = nombreHros;
    }
}
