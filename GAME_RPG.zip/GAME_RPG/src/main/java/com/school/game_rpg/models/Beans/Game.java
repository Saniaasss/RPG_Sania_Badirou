package com.school.game_rpg.models.Beans;

import com.school.game_rpg.utils.InputParser;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

public class Game {

    private ArrayList<HeroClass> HereosClass ;


    public static Game context;

    public static void playGame() {
        if (Game.context != null) {
            throw new RuntimeException
                    ("Impossible de lancer plusieurs fois la partie...");
        }
        Game.context = new Game();
        Game.context.generateHeroes();
        Game.context.startCombat();
    }

    public static enum Status {START_COMBAT, HERO_TURN, ENEMY_TURN,DEFENCE, END_GAME}
    public Status status;



    private List<Hero> heroes;
    public List<String> getHeroesStatus() {
        List<String> heroesStatus = new ArrayList<>();

        return heroesStatus;
    }
    private List<Enemy> enemies;
    public List<String> getEnemiesStatus() {
        List<String> enemyStatus = new ArrayList<>();

        return enemyStatus;
    }
    // "fighters" : Les héros et les ennemis mélangés
    private List<Fighter> fighters;
    ListIterator<Fighter> fightersIterator;

    private Fighter currentFighter;

    private int playerTurn;
    private InputParser inputParser;

    // L'instanciation de "Game" ne peut se faire que par "playGame"
    private Game() {}

    public void startCombat() {
        // Combat avec de nouveaux ennemis tant qu'il y a des héros actifs
        if (this.heroes.size() > 0) {
            this.status = Status.START_COMBAT;
            generateCombat();
        } else {
            this.status = Game.Status.END_GAME;
        }
    }

    public void generateCombat() {
        generateEnemies();
        shuffleFighters();
        // Initialise un "curseur" pour parcourir la liste des combattants
        fightersIterator = fighters.listIterator();
    }

    private void generateHeroes() {
        this.heroes = new ArrayList<>();

        // this.heroes.add(hero2);
        //  this.heroes.add(hero3);
        // this.heroes.add(hero4);
    }

    private void generateEnemies() {
        this.enemies = new ArrayList<>();
        enemies.add( new BasicEnemy() ); //--> un seul ennemi pour l'instant !

    }

    // Mélange les héros avec les ennemis dans une liste pour le combat
    private void shuffleFighters() {

        Collections.shuffle(this.fighters); //--> google "java shuffle list"
    }

    public void startNextFighterTurn() {

        if (this.heroes.size() == 0) {
            this.status = Game.Status.END_GAME;
        } else if (enemies.size() == 0) {
            this.status = Game.Status.START_COMBAT;
            generateCombat();
        } else {

            // Récupère le combattant suivant en déplaçant le curseur de liste
            if (!fightersIterator.hasNext()) {
                // Si on est à la fin de la liste, l'itérateur est réinitialisé
                fightersIterator = fighters.listIterator();
            }
            this.currentFighter = fightersIterator.next();



        }
    }

    public void startHeroTurn() {
        // Pour l'instant --> le joueur ne décide pas de l'action du héro
        //                --> le joueur attaque l'ennemi

    }

    public void startEnemyTurn() {
        // L'ennemi attaque au hasard un des héros encore vivant

    }

}
