package com.school.game_rpg.models.Beans;

public class BasicEnemy extends Enemy{
}
