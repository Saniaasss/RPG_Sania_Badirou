package com.school.game_rpg.models.entities;

public class EnemyGame extends Figher{
    private String enemie;
    private int vie;

    public EnemyGame() {
    }

    public EnemyGame(String enemie) {
        this.enemie = enemie;
    }

    public EnemyGame(int vie) {
        this.vie = vie;
    }

    public EnemyGame(String enemie, int vie) {
        this.enemie = enemie;
        this.vie = vie;
    }

    public String getEnemie() {
        return enemie;
    }

    public void setEnemie(String enemie) {
        this.enemie = enemie;
    }

    public int getVie() {
        return vie;
    }

    public void setVie(int vie) {
        this.vie = vie;
    }
}
