package com.school.game_rpg.models.Beans;

import java.util.ArrayList;
import java.util.List;

public abstract class Hero {

    private int armor;
    private int weaponDamage;
    private List<Potion> potions;
    private List<Food> lembas;

    public void defend() {

    }
    public void useConsumable(Consumable consumable) {

    }
}
