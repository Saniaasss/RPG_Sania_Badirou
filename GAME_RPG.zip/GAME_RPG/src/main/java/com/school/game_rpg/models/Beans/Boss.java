package com.school.game_rpg.models.Beans;

public class Boss extends Enemy{
}
