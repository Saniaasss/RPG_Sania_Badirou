package com.school.game_rpg.models.Beans;

public class Potion implements Consumable{

}