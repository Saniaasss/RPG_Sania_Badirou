package com.school.game_rpg.utils;

public class InputParser {
}
