package com.school.game_rpg.models.entities;


public class HeroGame extends Figher{
    private String name;
    private int vie;

    public HeroGame() {
    }

    public HeroGame(String name) {
        this.name = name;
    }

    public HeroGame(String name, int vie) {
        this.name = name;
        this.vie = vie;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getVie() {
        return vie;
    }

    public void setVie(int vie) {
        this.vie = vie;
    }
}
