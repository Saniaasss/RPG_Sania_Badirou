package com.school.game_rpg.models.entities;

import java.util.List;
import java.util.function.BooleanSupplier;

public  class Figher {

    private int lifePoints;


    public void setVie(int i) {
    }


}