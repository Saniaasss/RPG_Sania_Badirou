package com.school.game_rpg.controllers;

import com.school.game_rpg.MainApplication;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

import java.io.IOException;

public class MainController {
    @FXML
    private Label welcomeText,regle;
    @FXML
    private Button start, skip,help;

    @FXML
    protected void onWelcomeButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    protected void onStartButtonClick() throws IOException {
        // Affiche la fenêtre du jeu
        FXMLLoader fxmlLoader = new FXMLLoader
                (MainApplication.class.getResource("game.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        MainApplication.stage.setScene(scene);
        MainApplication.stage.show();
    }
    @FXML
    protected void onSkipButtonClick() {
        Platform.exit();
    }
    @FXML
    protected void onReadButtonClick() {
        welcomeText.setVisible(true);
        help.setVisible(false);
        regle.setText("\r \r REGLES DU JEU \n" +
                "Afin de jouer dans les meilleures conditions possibles, il faut s’assurer que certaines règles sont\n" +
                "respectées. En voici quelques exemples :\n" +
                "• Si l’on prend plus de dégâts que l’on a de PV, on meurt ;\n" +
                "• si aucun joueur n’est en vie, on a perdu ;\n" +
                "• si l’on n’a pas assez de mana, on ne peut pas lancer le sort ;\n" +
                "• on inflige bien les dégâts dans la bonne fourchette de dégâts ;\n" +
                "• la quantité de flèches diminue quand on tire ;\n" +
                "• la quantité de mana diminue après avoir lancé un sort ;\n" +
                "• l’attribution de récompense fonctionne bien après une victoire.");
        regle.setFocusTraversable(true);
        regle.setFont(Font.font(java.awt.Font.SERIF, 12));
        regle.setTextAlignment(TextAlignment.JUSTIFY);

    }

}