package com.school.game_rpg.models.entities;

public class GameClasse {
    private String label;
}
