package com.school.game_rpg.models.Beans;

import java.io.Serializable;

public class HeroClass implements Serializable {
    private  String heroClass;
    private int nombreTours;

    public HeroClass() {
    }

    public HeroClass(String heroClass) {
        this.heroClass = heroClass;
    }

    public HeroClass(int nombreTours) {
        this.nombreTours = nombreTours;
    }

    public HeroClass(String heroClass, int nombreTours) {
        this.heroClass = heroClass;
        this.nombreTours = nombreTours;
    }

    public String getHeroClass() {
        return heroClass;
    }

    public void setHeroClass(String heroClass) {
        this.heroClass = heroClass;
    }

    public int getNombreTours() {
        return nombreTours;
    }

    public void setNombreTours(int nombreTours) {
        this.nombreTours = nombreTours;
    }
}
