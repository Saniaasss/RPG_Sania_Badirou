package com.school.game_rpg.models.Beans;

public interface Consumable {
}
